function [ List_min_max ] = List_index_min_max( Vector,Value )
% clear;
% close all;
% Vector=sin((1:500)'.*(1/100*pi))>0;
% Value=1;
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
stop=0;
List_min_max=[];

N=size(Vector,1);
list_pos=find(Vector==Value);
pos=list_pos(1,1);
test=(1:N)';
% findr=min(test(list_pos(1,1)==Value))
while stop==0
if Vector(pos,1)~=Value
   
   pos=min(list_pos((list_pos-pos)>0));
    
end
    [pos_down,pos_up] = find_min_max_index_equal( pos,Vector,Value);
    
   List_min_max=[List_min_max;pos_down,pos_up];
   


pos=pos_up+1;
if pos>list_pos(end,1)
    stop=1;
end;

end

end