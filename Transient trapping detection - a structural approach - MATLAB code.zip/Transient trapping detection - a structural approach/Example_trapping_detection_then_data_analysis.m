
clear;
close all;

%% loading simulated trajectory
% alternating fractional Brownian Motion 
load('example_simulated_dataset.mat','X','Y','Z','groundtruth')
M=size(X,1); % trajectory number

%% Trapping analysis parameter
parameter=struct;
parameter.p_val_traj_type='fBm'; % can be 'Bm' or 'fBm'
parameter.diag_percentile=10;% can be 0,5,10 or 50 (10 in the article)
parameter.nu=0.75; % can be 0.1,0.3,0.5,0.75,0.9,1; (0.75 in the article)
parameter.p_value=0.05; % can be any percentile (minimum 0.01), (0.05 in the article)
parameter.list_mu=[1:0.5:2]; % maximum range ([0.5,,1,1.5,2,2.5,3]) ()
%% analyze dataset

dataset.X=X; % one row per trajectory
dataset.Y=Y; % one row per trajectory
dataset.Z=Z; % one row per trajectory

disp('Starting trapping analysis')
tic
[list_trapped] = Detect_transient_trapping_multiscale(dataset,parameter);
toc

%% plotting classification
Traj_number_to_plot=3; % number of trajectories to display
for m=1:min(M,Traj_number_to_plot)
    figure
    subplot(121)
    plot_nspec( [dataset.X(m,:);dataset.Y(m,:);dataset.Z(m,:)]' ,bwlabel(groundtruth(m,:)')+1);
    xlabel('X')
    ylabel('Y')
    title('Ground truth')
    subplot(122)
    plot_nspec( [dataset.X(m,:);dataset.Y(m,:);dataset.Z(m,:)]' ,bwlabel(list_trapped(m,:)')+1);
    xlabel('X')
    ylabel('Y')
    title('Our method')
end

%% trajectory portions analysis
disp('Starting trajectory portions analysis')
% parameters for TAMSD of free portions
parameter.TAMSD_localisation_error_std=0; % add if you know localisation error in same units as trajectory coordinates
parameter.TAMSD_min_traj_length_not_trapped=20;
parameter.TAMSD_MinWindowSize=1;
parameter.TAMSD_MaxWindowSize=5;% must be small compared to parameter.TAMSD_min_traj_length
% parameter for size of trap
parameter.perc_in_trap_for_size=95/100; % per/centile furthest point from center for half trap-size camputation
tic
[list_param_trapped,list_param_not_trapped] = Analysis_portions_trapped_not_trapped(dataset,list_trapped,parameter);
toc
%% Trapping radius empirical pdf
figure
hist(list_param_trapped(:,1),50)
ylabel('empirical pdf')
xlabel('trap radius')
title('Trapped portions')
%% Trapping duration  empirical pdf
figure
hist(list_param_trapped(:,end)-list_param_trapped(:,end-1),50)
ylabel('empirical pdf')
xlabel('trap duration')
title('Trapped portions')
%% Generalized diffusion coefficient empirical pdf for free protions
figure
hist(list_param_not_trapped(:,1),50)
ylabel('empirical pdf')
xlabel('D_\alpha')
title('Free portions')
%% anomalous exponenet empirical pdf for free protions
hist(list_param_not_trapped(:,2),linspace(0,2,20))
ylabel('empirical pdf')
xlabel('anomalous epxonent')
title('Free portions')

