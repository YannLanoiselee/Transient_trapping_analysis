function [list_vertical,list_diagonal,list_parallel,matrix] = RQA_3_measures(Trajectory,parameter)
N=size(Trajectory,1);
%% Laplacian matrix (distance matrix)
[S3] = laplacian_matrix(Trajectory,parameter.T_mean,parameter.mu_coef);
mat=S3>exp(-1);
%% fill diagonals
mat(diag(ones(N,1))==1)=1; % first diagonal
%         other diagonal depending on the radius size
num_max=parameter.diag_fill_list(2*parameter.mu_coef);
for num=1:num_max
    mat(num+1:end,1:end)=mat(num+1:end,1:end)+[diag(ones(N-num,1)),zeros(N-num,num)];
    mat(1:end,num+1:end)=mat(1:end,num+1:end)+[diag(ones(N-num,1));zeros(num,N-num)];
end
%% select matrix part connex to the diagonal line
L = bwlabel(mat,8);
matrix=zeros(size(L));
matrix(L==1)=1;
%% fill holes
matrix = imfill(matrix,'holes');
%% init analysis
list_diagonal=zeros(N,1);
list_vertical=zeros(N,1);
list_parallel=zeros(N,1);
%% analysis
for n=1:N
    %% distribution of vertical lines
    if n<=N/2
        list_diag_ind=[(1:2*n-1)',(2*n-1:-1:1)'];
    else
        list_diag_ind=[(2*n-N:N)',(N:-1:2*n-N)'];
    end
    list_bin_vert=matrix(sub2ind(size(matrix),list_diag_ind(:,1),list_diag_ind(:,2)));
    index=find(list_diag_ind(:,1)==n & list_diag_ind(:,2)==n);
    [pos_down,pos_up] = find_min_max_index_equal( index,list_bin_vert==1,1);
    %% vertical
    list_vertical(n,1)=sum(double(matrix(:,n)));%list_pos(end,1)-list_pos(1,1);
    
    %% diagonal
    list_diagonal(n,1)=pos_up-pos_down+1;
    %% parallel
    [pos_down_par,pos_up_par] = find_min_max_index_equal( n-(list_diagonal(n,1)-1)/2,diag(matrix,list_diagonal(n,1)-1) ,1);
    list_parallel(n,1)=pos_up_par-pos_down_par+1;
end

    function [S3] = laplacian_matrix(Traj,T_mean,mu_coef)
        %UNTITLED3 Summary of this function goes here
        %   Detailed explanation goes here
        No=size(Traj,1);
        
        inc=diff(Traj,1,1);
        Traj=cumsum([zeros(1,size(Traj,2));inc./repmat(std(inc,0,1),size(inc,1),1)],1);
        mu=mu_coef;
        S=zeros(No,No);
        for i=1:No
            S(:,i)=sum((Traj-repmat(Traj(i,:),No,1)).^2,2);%((Xo-Xo(i,1)).^2+(Yo-Yo(i,1)).^2).^0.5;
            S(i,:)=S(:,i)';
        end
        S2b=exp(-1/2*S/mu^2);
        S3=conv2(S2b,ones(2*T_mean+1,2*T_mean+1)./(2*T_mean+1)^2,'same');
    end
end

