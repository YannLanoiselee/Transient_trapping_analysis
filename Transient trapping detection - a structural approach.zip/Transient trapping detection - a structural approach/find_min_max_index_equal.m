% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)
function [pos_down,pos_up] = find_min_max_index_equal( index,Vector_to_test,quantity)
% Return min and max index equal of result where vector_to_test==quantity
% quantity default value is 1
% 0 0 0    1      1   1   1 1   1 0  0 0
%       pos_down    index    pos_up
%Testing continuous path
N=size(Vector_to_test,1);
if nargin==2
    quantity=1;
end
stop_up=0;
stop_down=0;
pos_up=index;
pos_down=index;
for z=1:N
    if stop_up==0
        if pos_up+1<=N
            if Vector_to_test(pos_up+1,1)==quantity
                pos_up=pos_up+1;
            else
                stop_up=1;
            end
        else
            stop_up=1;
        end
    end
    if stop_down==0
        if pos_down-1>=1
            if Vector_to_test(pos_down-1,1)==quantity
                pos_down=pos_down-1;
            else
                stop_down=1;
            end
        else
            stop_down=1;
        end
    end
    if stop_up==1 && stop_down==1
        break
    end
end
end

