% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)
function [list_trapped,list_vertical,list_diagonal,list_parallel] = Detect_transient_trapping_multiscale(dataset,parameter)
% Transient trapping detection 
% Analyse M trajectories of N points

%Yann Lanoiselée, Jak Grimes, Zsombor Koszegi, Davide Calebiro (2021)



%% Input parameters description
% dataset.X : X coordinates  M x N frames matrix (use NaNs for missing points) 

% dataset.Y : Y coordinates  M x N frames matrix (use NaNs for missing points)

% dataset.Z : Z coordinates  M x N frames matrix (use NaNs for missing points)

% parameter.p_value : p_value for block duration for being considered not to be due to chance
%           can be any percentile (minimum 0.01), (0.05 in the article)

% parameter.list_mu=[1:0.5:2]; 
%           maximum range ([0.5,1,1.5,2,2.5,3]) ()

% parameter.p_val_traj_type= reference motion type for simulations
%            can be 'Bm' or 'fBm'

% parameter.diag_percentile= Percentile of block time from reference free
% motion to be used to fill diagonal lines
%           can be 0,5,10 or 50 (10 in the article)

% parameter.nu : Critical value for the invariant (1 is perfect square)
%           can be 0.1,0.3,0.5,0.75,0.9,1; (0.75 in the article)


%% Output parameters description


%% default parameters
if ~isfield(parameter,'p_val_traj_type')
parameter.p_val_traj_type='fBm'; % can be 'Bm' or 'fBm'
end
if ~isfield(parameter,'diag_percentile')
parameter.diag_percentile=10;% can be 0,5,10 or 50 (10 in the article)
end
if ~isfield(parameter,'nu')
parameter.nu=0.75; % can be 0.1,0.3,0.5,0.75,0.9,1; (0.75 in the article)
end
if ~isfield(parameter,'p_value')
parameter.p_value=0.05; % can be any percentile (minimum 0.01), (0.05 in the article)
end
if ~isfield(parameter,'list_mu')
parameter.list_mu=[1:0.5:2]; % maximum range ([0.5,,1,1.5,2,2.5,3]) ()
end
parameter.T_mean=2; % must stay 2
parameter.sig_noise=0; % must stay 0

%% finding path of the file where MUST be located the file for diagonal filling and the files for threshold values
function_folder_path=mfilename('fullpath');
function_folder_path=function_folder_path(1:end-numel(mfilename));

%% input
if isfield(dataset,'X') && isfield(dataset,'Y')
if isfield(dataset,'Z')
if ~isempty(dataset.Z)
ndim=3;
else
ndim=2;
end
else
ndim=2;
end
else
error('Must provide dataset.X and dataset.Y for 2D and add dataset.Z for 3D')
end
%% loading diag filling data
load([function_folder_path,'data_set_method',filesep,'list_percentile',num2str(parameter.diag_percentile),'_vertical_fct_lambda_diag_part_tofill.mat']);
parameter.diag_fill_list=list_vert_median.([parameter.p_val_traj_type,'_',num2str(ndim),'D']);

%% thresholding
if isfield (parameter,'p_val_traj_type')
if strcmp(parameter.p_val_traj_type,'Bm')==1 || strcmp(parameter.p_val_traj_type,'fBm')==1
load([function_folder_path,'data_set_method',filesep,'list_threshold_RQA_Bm_fBm_2D_3D_nuc',num2str(100*parameter.nu),'diag_perc=',num2str(parameter.diag_percentile),'_T_mean=',num2str(parameter.T_mean),'_signoise=',num2str(parameter.sig_noise),'.mat']);
else
error('Error parameter parameter.p_val_traj_type can only be ''Bm'' or ''fBm''')
end
else
error('Error parameter parameter.p_val_traj_type must be inputted.  Can only accept ''Bm'' or ''fBm''')
end

M=size(dataset.X,1);
N=size(dataset.X,2);
list_trapped=nan(size(dataset.X));
list_trapped(~isnan(dataset.X))=0;
list_vertical=nan(size(dataset.X));
list_diagonal=nan(size(dataset.X));
list_parallel=nan(size(dataset.X));

list_vertical(~isnan(dataset.X))=0;
list_diagonal(~isnan(dataset.X))=0;
list_parallel(~isnan(dataset.X))=0;
if ndim==2
list_exist=~isnan(dataset.X) & ~isnan(dataset.Y);
elseif ndim==3
list_exist=~isnan(dataset.X) & ~isnan(dataset.Y) & ~isnan(dataset.Z);
end
for m=1:M
exist_traj=list_exist(m,:);
length_traj=sum(double(exist_traj));
if ndim==2
Traj=[dataset.X(m,exist_traj);dataset.Y(m,exist_traj)]';
elseif ndim==3
Traj=[dataset.X(m,exist_traj);dataset.Y(m,exist_traj);dataset.Z(m,exist_traj)]';    
end

for n_mu=1:numel(parameter.list_mu) 
parameter.mu_coef=parameter.list_mu(1,n_mu);
crit=list_threshold.([parameter.p_val_traj_type,'_',num2str(ndim),'D'])(parameter.mu_coef/0.5,(1-parameter.p_value)*100);
if length_traj>crit

[list_vertical_m,list_diagonal_m,list_parallel_m] = RQA_block_measures(Traj,parameter);
list_trapped_m=list_vertical_m./(list_parallel_m+list_diagonal_m-1)>parameter.nu;
[ List_min_max ] = Make_list_min_max_index_equal(list_trapped_m,1);
if ~isempty(List_min_max)
list_index_false_trap=find((List_min_max(:,2)-List_min_max(:,1)+1)<=crit);
if ~isempty(list_index_false_trap)
for n_false=1:numel(list_index_false_trap)
list_trapped_m(List_min_max(list_index_false_trap(n_false,1),1):List_min_max(list_index_false_trap(n_false,1),2))=0;
end
end
end
list_trapped(m,exist_traj)=list_trapped(m,exist_traj)+list_trapped_m';
list_trapped(m,exist_traj)=list_trapped(m,exist_traj)>0;
list_vertical(m,exist_traj)=list_vertical_m';
list_diagonal(m,exist_traj)=list_diagonal_m';
list_parallel(m,exist_traj)=list_parallel_m';
end
end
end
end

