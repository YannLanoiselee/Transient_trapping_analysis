% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)
function [fit_param ] = NonLinearFitTAMSD_anomalous(t, curve_to_fit )
%fit of the form TAMSD(t)=D*t^alpha+sigma
%t time variable

% fit_param(1,1)=2D in 1dim or 4D in 2dim 
% fit_param(1,2)= anomalous exponent
% fit_param(1,3)= estimated variance of noise 2sigma_err^2 in 1dim or 2sigma_err^2 in 2dim 

y=curve_to_fit;
F = @(x,xdata)x(1)*xdata.^x(2)+x(3);
x0 = [curve_to_fit(1,1) 1 0];
opts = optimoptions('lsqcurvefit','TolX',10^(-14),'TolFun',10^(-14),'Display','off');
[fit_param] = lsqcurvefit(F,x0,t,y,[0,0,0],[max(curve_to_fit),2,max(curve_to_fit)],opts);%,'MaxFunEvals',5*10^2);
end

