function [list_param_trapped,list_param_not_trapped] = Analysis_portions_trapped_not_trapped(dataset,list_trapped,parameter)
%% check data dimensionality
if isfield(dataset,'X') && isfield(dataset,'Y')
    if isfield(dataset,'Z')
        if ~isempty(dataset.Z)
            ndim=3;
        else
            ndim=2;
        end
    else
        ndim=2;
    end
else
    error('Must provide dataset.X and dataset.Y for 2D and add dataset.Z for 3D')
end
%% copy data
X_tot=dataset.X;
Y_tot=dataset.Y;
if ndim==3
    Z_tot=dataset.Z;
end

M=size(X_tot,1);
%% finds not-nan data points
if ndim==2
    list_exist=~isnan(X_tot) & ~isnan(Y_tot);
elseif ndim==3
    list_exist=~isnan(X_tot) & ~isnan(Y_tot) & ~isnan(Z_tot);
end

list_param_not_trapped=[];
list_param_trapped=[];

for m=1:M
    X=X_tot(m,:);
    X=X(1,list_exist(m,:));
    Y=Y_tot(m,:);
    Y=Y(1,list_exist(m,:));
    
    if ndim==3
        Z=Z_tot(m,:);
        Z=Z(1,list_exist(m,:));
        
    end
    
    
    if any(list_exist(m,:))==1
        %             TAMSD analysis of non trapped
        [ List_min_max ] =Make_list_min_max_index_equal(list_trapped(m,list_exist(m,:))',0 );
        if ~isempty(List_min_max)
            for n_subtraj=1:size(List_min_max,1)
                
                if List_min_max(n_subtraj,2)-List_min_max(n_subtraj,1)+1>=parameter.TAMSD_min_traj_length_not_trapped
                    if ndim==2
                        [list_TAMSD] = TAMSD_Trajectory_XYZ( X(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',Y(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',[],parameter);
                    elseif ndim==3
                        [list_TAMSD] = TAMSD_Trajectory_XYZ( X(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',Y(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',Z(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',parameter);
                    end
                    
                    list_TAMSD=sum(list_TAMSD,2)-4*parameter.TAMSD_localisation_error_std.^2;
                    [fit_param] = NonLinearFitTAMSD_anomalous((parameter.TAMSD_MinWindowSize:parameter.TAMSD_MaxWindowSize)', list_TAMSD(parameter.TAMSD_MinWindowSize:parameter.TAMSD_MaxWindowSize,1) );
                    fit_param(1,1)=fit_param(1,1)/(2*ndim);
                    param_not_trapped=[fit_param,List_min_max(n_subtraj,2)-List_min_max(n_subtraj,1)+1,m,List_min_max(n_subtraj,1),List_min_max(n_subtraj,2)];
                    list_param_not_trapped=[list_param_not_trapped;param_not_trapped];
                    % fit_param
                end
            end
        end
        %% TAMSD analysis of trapped
        [ List_min_max ] = Make_list_min_max_index_equal(list_trapped(m,list_exist(m,:))',1 );
        
        if ~isempty(List_min_max)
            for n_subtraj=1:size(List_min_max,1)
                center=median([X(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))',Y(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))'],1);
                
                x=X(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))'-center(1);
                y=Y(1,List_min_max(n_subtraj,1):List_min_max(n_subtraj,2))'-center(2);
                dist=(x.^2+y.^2).^0.5;
                list=sortrows([dist,x,y],1);
                radius=list(round(size(list,1)*parameter.perc_in_trap_for_size));
                
                param_trapped=[radius,m,List_min_max(n_subtraj,1),List_min_max(n_subtraj,2)];
                list_param_trapped=[list_param_trapped;param_trapped];
            end
        end
    end
end
end

