% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)
function [List_TAMSD] = TAMSD_Trajectory_XYZ( X,Y,Z,parameter )
%TAMSD pour une trajectoire
%<X^2>=D*t^\alpha+sigma^2
N=size(X,1);
M=size(X,2);
List_TAMSD=zeros(parameter.TAMSD_MaxWindowSize,1);
if isempty(Z)
for WindowSize=parameter.TAMSD_MinWindowSize:parameter.TAMSD_MaxWindowSize
List_TAMSD(WindowSize,:)=nanmean((X(WindowSize+1:end,:)-X(1:end-WindowSize,:)).^2,1)+nanmean((Y(WindowSize+1:end,:)-Y(1:end-WindowSize,:)).^2,1);
end
else
for WindowSize=parameter.TAMSD_MinWindowSize:parameter.TAMSD_MaxWindowSize
List_TAMSD(WindowSize,:)=nanmean((X(WindowSize+1:end,:)-X(1:end-WindowSize,:)).^2,1)+nanmean((Y(WindowSize+1:end,:)-Y(1:end-WindowSize,:)).^2,1)+nanmean((Z(WindowSize+1:end,:)-Z(1:end-WindowSize,:)).^2,1);
end

end

