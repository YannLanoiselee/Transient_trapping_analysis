% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)
function [] = plot_nspec( Trajectory ,n_vec,color)
%plot the trajectory with n colors according to clusters in n_vec from 1 to n


n_color=max(n_vec);
if nargin==2
color=lines;
color=[0,0,0;1,0,0;color];
end
N=size(Trajectory,1);
d=size(Trajectory,2);
X=Trajectory(:,1);
Y=Trajectory(:,2);
if d==3
Z=Trajectory(:,3);
end

for n_cond=1:n_color
binaryVec=n_vec==n_cond;
if sum(binaryVec)>0
[ List_min_max ] = List_index_min_max( binaryVec,1 );
for m=1:size(List_min_max,1)
hold all
if List_min_max(m,1)==1
posi=List_min_max(m,1):List_min_max(m,2);

else
posi=(List_min_max(m,1)-1):List_min_max(m,2);
end
if d==2
p=plot(X(posi,1),Y(posi,1),'Color',color(mod(n_cond-1,65)+1,:));
set(get(get(p,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
elseif d==3
plot3(X(posi,1),Y(posi,1),Z(posi,1),'Color',color(mod(n_cond-1,65)+1,:))
end
end
end
end

end

