% Copyright (c) Lanoisel�e 2021
% When using this code please cite:
% Detecting Transient Trapping from a Single Trajectory: A Structural Approach
% Y Lanoisel�e, J Grimes, Z Koszegi, D Calebiro
% Entropy 23 (8), 1044 (2021)

clear;
close all;
parameter.p_val_traj_type='fBm'; % can be 'Bm' or 'fBm'
parameter.T_mean=2; % must stay 2
parameter.sig_noise=0; % must stay 0
parameter.diag_percentile=10;% can be 0,5,10 or 50
parameter.nu=0.75; % can be 0.1,0.3,0.5,0.75,0.9,1; 0.75 is recommended
parameter.p_value=0.05; % can be any percentile (minimum 0.01)
parameter.list_mu=[1:0.5:2]; % maximum range ([0.5,,1,1.5,2,2.5,3])


%% simulation parameters
lambda_min=0;
lambda_max=2;
ndim=2;
D=1/2;
H=0.35;
T_f=50;
T_t=20;
p_f0=1/2;
M=1000;
pdf_size_trap=@(x) unifpdf(x,lambda_min,lambda_max);%
n_trap=100;
list_lambda=linspace(lambda_min,lambda_max,n_trap);
N=200;


[X,Y,Z,istrapped] = traj_altern_fBm_conf_3D_v2(N,list_lambda,pdf_size_trap(list_lambda),D,H,T_f,T_t,p_f0,M);

istrapped=istrapped';
groundtruth=istrapped;
X=X';
Y=Y';
Z=Z';
save('example_simulated_dataset','X','Y','Z','groundtruth')


%% analyze dataset 

dataset.X=X; % trajectory coordinates are rows
dataset.Y=Y;
if ndim==3
dataset.Z=Z;
end
tic
[list_trapped,list_vertical,list_diagonal,list_parallel] = Detect_transient_trapping_multiscale(dataset,parameter);
toc
%% plotting classification
Traj_number_to_plot=3; % number of trajectories to display
for m=1:min(M,Traj_number_to_plot)%
figure
if ndim==3
subplot(121)
plot2D_nspec( [dataset.X(m,:);dataset.Y(m,:);dataset.Z(m,:)]' ,bwlabel(istrapped(m,:)')+1);
xlabel('X')
ylabel('Y')
title('Ground truth')
subplot(122)
plot2D_nspec( [dataset.X(m,:);dataset.Y(m,:);dataset.Z(m,:)]' ,bwlabel(list_trapped(m,:)')+1);
xlabel('X')
ylabel('Y')
title('Our method')


elseif ndim==2
subplot(121)
plot2D_nspec( [dataset.X(m,:);dataset.Y(m,:)]' ,bwlabel(istrapped(m,:)')+1);
xlabel('X')
ylabel('Y')
title('Ground truth')
subplot(122)
plot2D_nspec( [dataset.X(m,:);dataset.Y(m,:)]' ,bwlabel(list_trapped(m,:)')+1);
xlabel('X')
ylabel('Y')
title('Our method')
end
end

%% subtrajectoy analysis
parameter.TAMSD_localisation_error_std=0; % add if you know localisation error in same units as trajectory coordinates
parameter.TAMSD_min_traj_length_trapped=50;
parameter.TAMSD_min_traj_length_not_trapped=20;

parameter.TAMSD_MinWindowSize=1;
parameter.TAMSD_MaxWindowSize=5;% must be small compared to parameter.TAMSD_min_traj_length
parameter.perc_in_trap_for_size=90/100;

[list_param_trapped,list_param_not_trapped] = Analysis_portions_trapped_not_trapped(dataset,list_trapped,parameter);
%%
figure
hist(list_param_trapped(:,1),50)
ylabel('empirical pdf')
xlabel('trap radius')
title('Trapped portions')
%%
figure
hist(list_param_trapped(:,end)-list_param_trapped(:,end-1),50)
ylabel('empirical pdf')
xlabel('trap duration')
title('Trapped portions')
%%
figure
hist(list_param_not_trapped(:,1),50)
ylabel('empirical pdf')
xlabel('D_\alpha')
title('Free portions')

hist(list_param_not_trapped(:,2),linspace(0,2,20))
ylabel('empirical pdf')
xlabel('anomalous epxonent')
title('Free portions')

